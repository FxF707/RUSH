# Medieval Rush — Unity prototype 0.1

Starter project for Unity 2022.3 LTS. This is a procedural greybox prototype: it builds its scene from primitives and does not require third-party assets.

## Open
1. Install Unity Hub and Unity Editor 2022.3 LTS (or a compatible newer LTS version).
2. In Unity Hub choose **Add > Add project from disk** and select this folder.
3. Open the project. The prototype auto-starts when entering Play mode.
4. For Android, install **Android Build Support**, Android SDK & NDK Tools, and OpenJDK through Unity Hub. Open Build Profiles/Build Settings, select Android, switch platform, and build an APK for testing.

## Controls
- Left/right arrows or A/D: change lane
- Up arrow/W/Space: jump
- Down arrow/S: slide
- C: cycle through the three character color concepts
- Touch/swipe: mobile lane change, jump, and slide
- After a collision, tap or press Space to restart

## Included
- Three-lane endless-runner greybox
- Procedural medieval railway setting, obstacle blocks, train cars, and coins
- Three provisional character looks: all-black ninja, gold king with crown, purple/magenta kunoichi
- Gradual speed increase with a maximum cap
- Distance/coin HUD and restart flow

## Current limitations
This is source code for an early prototype, not a compiled or device-tested APK. Character models are primitive placeholders rather than final rigged 3D assets; train/track art, rocket hoverboard, polished animations, audio, menus, persistence, and store compliance remain future work. Test and adjust the project in the target Unity version before release.
