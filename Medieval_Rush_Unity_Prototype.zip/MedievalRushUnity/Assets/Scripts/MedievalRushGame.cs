using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Procedural starter prototype for Medieval Rush. No external assets required.</summary>
public class MedievalRushGame : MonoBehaviour
{
    [Header("Run settings")]
    public float baseSpeed = 12f;
    public float maxSpeed = 27f;
    public float laneWidth = 3f;
    public float jumpHeight = 2.3f;
    public float jumpDuration = 0.72f;
    public float slideDuration = 0.7f;

    private int lane = 1;
    private int characterIndex = 0;
    private float runTime;
    private float speed;
    private float jumpTimer;
    private float slideTimer;
    private float spawnTimer;
    private float distance;
    private int coins;
    private bool gameOver;
    private Vector2 touchStart;
    private Transform player;
    private Transform playerVisual;
    private Camera gameCamera;
    private Text hud;
    private Text hint;
    private Material[] characterMaterials;
    private readonly System.Collections.Generic.List<GameObject> worldObjects = new System.Collections.Generic.List<GameObject>();

    void Start()
    {
        Application.targetFrameRate = 60;
        CreateMaterials();
        CreateEnvironment();
        CreatePlayer();
        CreateCamera();
        CreateUI();
        speed = baseSpeed;
    }

    void Update()
    {
        if (gameOver)
        {
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0) || Input.touchCount > 0) Restart();
            return;
        }

        HandleInput();
        runTime += Time.deltaTime;
        speed = Mathf.Min(maxSpeed, baseSpeed + runTime * 0.32f); // gradual, capped difficulty
        distance += speed * Time.deltaTime;
        jumpTimer = Mathf.Max(0, jumpTimer - Time.deltaTime);
        slideTimer = Mathf.Max(0, slideTimer - Time.deltaTime);

        Vector3 target = new Vector3((lane - 1) * laneWidth, 0, 0);
        player.position = Vector3.Lerp(player.position, target, 12f * Time.deltaTime);
        float jumpY = jumpTimer > 0 ? Mathf.Sin((1f - jumpTimer / jumpDuration) * Mathf.PI) * jumpHeight : 0;
        playerVisual.localPosition = new Vector3(0, jumpY, 0);
        playerVisual.localScale = slideTimer > 0 ? new Vector3(0.9f, 0.55f, 0.9f) : Vector3.one;

        foreach (GameObject obj in worldObjects)
        {
            if (obj == null) continue;
            obj.transform.position += Vector3.back * speed * Time.deltaTime;
        }
        for (int i = worldObjects.Count - 1; i >= 0; i--)
        {
            GameObject obj = worldObjects[i];
            if (obj == null || obj.transform.position.z < -18f)
            {
                if (obj != null) Destroy(obj);
                worldObjects.RemoveAt(i);
            }
            else if (obj.CompareTag("Coin") && Vector3.Distance(obj.transform.position, player.position + Vector3.up) < 1.25f)
            {
                coins++; Destroy(obj); worldObjects.RemoveAt(i);
            }
            else if ((obj.CompareTag("Obstacle") || obj.CompareTag("Train")) &&
                     Mathf.Abs(obj.transform.position.z - player.position.z) < 1.25f &&
                     Mathf.Abs(obj.transform.position.x - player.position.x) < 1.15f && jumpTimer <= 0.05f && slideTimer <= 0.05f)
            {
                EndRun();
            }
        }

        spawnTimer -= Time.deltaTime;
        if (spawnTimer <= 0) { SpawnWave(); spawnTimer = Random.Range(1.0f, Mathf.Max(1.25f, 2.2f - runTime * 0.008f)); }
        hud.text = $"MEDIEVAL RUSH\nDistância  {(int)distance} m     Moedas  {coins}\nVelocidade  {speed:0.0}";
    }

    void HandleInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) lane = Mathf.Max(0, lane - 1);
        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) lane = Mathf.Min(2, lane + 1);
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Space)) jumpTimer = jumpDuration;
        if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) slideTimer = slideDuration;
        if (Input.GetKeyDown(KeyCode.C)) SwitchCharacter();

        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);
            if (t.phase == TouchPhase.Began) touchStart = t.position;
            if (t.phase == TouchPhase.Ended)
            {
                Vector2 d = t.position - touchStart;
                if (d.magnitude < 35) return;
                if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) lane = Mathf.Clamp(lane + (d.x > 0 ? 1 : -1), 0, 2);
                else if (d.y > 0) jumpTimer = jumpDuration;
                else slideTimer = slideDuration;
            }
        }
        if (Input.GetMouseButtonDown(0)) touchStart = Input.mousePosition;
        if (Input.GetMouseButtonUp(0))
        {
            Vector2 d = (Vector2)Input.mousePosition - touchStart;
            if (d.magnitude > 50)
            {
                if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) lane = Mathf.Clamp(lane + (d.x > 0 ? 1 : -1), 0, 2);
                else if (d.y > 0) jumpTimer = jumpDuration; else slideTimer = slideDuration;
            }
        }
    }

    void CreateMaterials()
    {
        characterMaterials = new Material[3];
        characterMaterials[0] = Mat(new Color(0.025f,0.025f,0.03f)); // all-black ninja
        characterMaterials[1] = Mat(new Color(0.83f,0.53f,0.08f)); // gold king
        characterMaterials[2] = Mat(new Color(0.42f,0.08f,0.65f)); // purple kunoichi
    }

    Material Mat(Color c) { var m = new Material(Shader.Find("Standard")); m.color = c; return m; }

    GameObject Cube(string name, Vector3 pos, Vector3 scale, Material mat, Transform parent = null)
    {
        GameObject o = GameObject.CreatePrimitive(PrimitiveType.Cube); o.name = name; o.transform.position = pos; o.transform.localScale = scale;
        if (parent != null) o.transform.SetParent(parent, true);
        if (mat != null) o.GetComponent<Renderer>().material = mat;
        return o;
    }

    void CreateEnvironment()
    {
        var ground = Mat(new Color(0.24f,0.22f,0.19f));
        var rail = Mat(new Color(0.36f,0.37f,0.39f));
        var wood = Mat(new Color(0.25f,0.12f,0.06f));
        Cube("Track Bed", new Vector3(0,-0.35f,15), new Vector3(10,0.4f,100), ground);
        for (int l=0;l<3;l++)
        {
            float x=(l-1)*laneWidth;
            Cube("Rail L", new Vector3(x-0.65f,-0.08f,15), new Vector3(0.12f,0.16f,100), rail);
            Cube("Rail R", new Vector3(x+0.65f,-0.08f,15), new Vector3(0.12f,0.16f,100), rail);
            for(int z=-30;z<70;z+=3) Cube("Sleeper",new Vector3(x,-0.17f,z),new Vector3(1.5f,0.12f,0.35f),wood);
        }
        var wall = Mat(new Color(0.32f,0.29f,0.25f));
        for(int side=-1;side<=1;side+=2)
        {
            Cube("Castle wall",new Vector3(side*6,1,18),new Vector3(1,2,100),wall);
            for(int z=-25;z<70;z+=8) Cube("Wall merlon",new Vector3(side*6,2.3f,z),new Vector3(1.1f,0.7f,1.2f),wall);
        }
        RenderSettings.ambientLight = new Color(0.72f,0.72f,0.72f);
    }

    void CreatePlayer()
    {
        player = new GameObject("Player Root").transform;
        player.position = new Vector3(0,0,0);
        playerVisual = new GameObject("Player Visual").transform; playerVisual.SetParent(player,false);
        BuildCharacter();
    }

    void BuildCharacter()
    {
        foreach(Transform child in playerVisual) Destroy(child.gameObject);
        Material body = characterMaterials[characterIndex];
        Material pants = characterIndex==1 ? Mat(new Color(0.045f,0.04f,0.035f)) : body;
        Material accent = characterIndex==0 ? body : (characterIndex==1 ? Mat(new Color(1f,0.68f,0.08f)) : Mat(new Color(0.9f,0.08f,0.65f)));
        Cube("Fitted top",new Vector3(0,1.25f,0),new Vector3(0.65f,0.8f,0.38f),body,playerVisual);
        Cube("Baggy pants",new Vector3(0,0.53f,0),new Vector3(0.9f,0.68f,0.44f),pants,playerVisual);
        Cube("Head",new Vector3(0,1.9f,0),new Vector3(0.48f,0.48f,0.45f),body,playerVisual);
        Cube("Left leg",new Vector3(-0.24f,0.22f,0),new Vector3(0.42f,0.48f,0.42f),pants,playerVisual);
        Cube("Right leg",new Vector3(0.24f,0.22f,0),new Vector3(0.42f,0.48f,0.42f),pants,playerVisual);
        Cube("Left sneaker",new Vector3(-0.24f,0.07f,0.12f),new Vector3(0.48f,0.18f,0.65f),accent,playerVisual);
        Cube("Right sneaker",new Vector3(0.24f,0.07f,0.12f),new Vector3(0.48f,0.18f,0.65f),accent,playerVisual);
        Cube("Left arm",new Vector3(-0.48f,1.28f,0),new Vector3(0.2f,0.72f,0.24f),body,playerVisual);
        Cube("Right arm",new Vector3(0.48f,1.28f,0),new Vector3(0.2f,0.72f,0.24f),body,playerVisual);
        if(characterIndex==1) Cube("Gold crown",new Vector3(0,2.2f,0),new Vector3(0.6f,0.18f,0.5f),accent,playerVisual);
        if(characterIndex==2) Cube("Hair tie",new Vector3(0,2.15f,-0.3f),new Vector3(0.22f,0.22f,0.35f),accent,playerVisual);
    }

    void SwitchCharacter() { characterIndex=(characterIndex+1)%3; BuildCharacter(); }

    void CreateCamera()
    {
        var c = new GameObject("Runner Camera"); gameCamera=c.AddComponent<Camera>();
        gameCamera.transform.position = new Vector3(0,5.2f,-8.5f); gameCamera.transform.rotation=Quaternion.Euler(17,0,0);
        gameCamera.fieldOfView=65; gameCamera.backgroundColor=new Color(0.45f,0.58f,0.68f);
        gameCamera.clearFlags=CameraClearFlags.SolidColor;
    }

    void CreateUI()
    {
        var canvasObj=new GameObject("HUD Canvas"); var canvas=canvasObj.AddComponent<Canvas>(); canvas.renderMode=RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>().uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize; canvasObj.AddComponent<GraphicRaycaster>();
        hud=MakeText(canvas.transform,"HUD",new Vector2(0.02f,0.98f),new Vector2(0.02f,0.98f),new Vector2(0,1),24);
        hint=MakeText(canvas.transform,"Hint",new Vector2(0.5f,0.04f),new Vector2(0.5f,0.04f),new Vector2(0.5f,0),18);
        hint.alignment=TextAnchor.LowerCenter; hint.text="Deslize: mover • cima: pular • baixo: deslizar • C: trocar personagem";
    }

    Text MakeText(Transform parent,string name,Vector2 amin,Vector2 amax,Vector2 pivot,int size)
    {
        var go=new GameObject(name); go.transform.SetParent(parent,false); var r=go.AddComponent<RectTransform>();
        r.anchorMin=amin;r.anchorMax=amax;r.pivot=pivot;r.anchoredPosition=Vector2.zero;r.sizeDelta=new Vector2(800,130);
        var t=go.AddComponent<Text>();t.font=Resources.GetBuiltinResource<Font>("Arial.ttf");t.fontSize=size;t.color=Color.white;t.fontStyle=FontStyle.Bold;t.horizontalOverflow=HorizontalWrapMode.Overflow;t.verticalOverflow=VerticalWrapMode.Overflow;return t;
    }

    void SpawnWave()
    {
        int safeLane=Random.Range(0,3);
        for(int l=0;l<3;l++)
        {
            float x=(l-1)*laneWidth;
            if(l!=safeLane && Random.value<0.72f)
            {
                bool train=Random.value<0.28f;
                var o=Cube(train?"Medieval train car":"Obstacle",new Vector3(x,train?0.9f:0.55f,48),train?new Vector3(2.1f,2.3f,8f):new Vector3(1.5f,1.1f,1.2f),train?Mat(new Color(0.35f,0.22f,0.12f)):Mat(new Color(0.48f,0.22f,0.12f)));
                o.tag=train?"Train":"Obstacle"; worldObjects.Add(o);
                if(train) { Cube("Train gold trim",new Vector3(x,1.45f,48),new Vector3(2.15f,0.12f,8f),Mat(new Color(0.78f,0.55f,0.12f)),o.transform); }
            }
        }
        int coinLane=Random.Range(0,3);
        for(int i=0;i<5;i++)
        {
            var coin=GameObject.CreatePrimitive(PrimitiveType.Sphere);coin.name="Coin";coin.tag="Coin";
            coin.transform.position=new Vector3((coinLane-1)*laneWidth,1.2f,43+i*1.7f);coin.transform.localScale=Vector3.one*0.38f;
            coin.GetComponent<Renderer>().material=Mat(new Color(1f,0.72f,0.05f));Destroy(coin.GetComponent<Collider>());worldObjects.Add(coin);
        }
    }

    void EndRun()
    {
        gameOver=true; hint.text=$"FIM DE JOGO • Distância {(int)distance} m • Moedas {coins}\nToque ou pressione ESPAÇO para reiniciar";
    }

    void Restart()
    {
        foreach(var o in worldObjects) if(o!=null) Destroy(o);worldObjects.Clear();
        runTime=0;distance=0;coins=0;lane=1;spawnTimer=0;jumpTimer=0;slideTimer=0;gameOver=false;
        player.position=Vector3.zero;hint.text="Deslize: mover • cima: pular • baixo: deslizar • C: trocar personagem";
    }
}
