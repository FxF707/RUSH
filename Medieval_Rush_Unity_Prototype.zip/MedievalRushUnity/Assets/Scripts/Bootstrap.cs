using UnityEngine;

public static class MedievalRushBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void StartGame()
    {
        if (Object.FindObjectOfType<MedievalRushGame>() == null)
            new GameObject("Medieval Rush Game").AddComponent<MedievalRushGame>();
    }
}
