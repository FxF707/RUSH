The current prototype creates its scene procedurally at runtime. Open the project and press Play; no authored scene file is required for this starter.
